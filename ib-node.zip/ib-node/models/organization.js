/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const organization = sequelize.define('organization', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    type: {
      type: DataTypes.ENUM('university','corporate'),
      allowNull: false
    },
    url: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'organization'
  });
  organization.associate = function(models) {
	  organization.hasMany(models.organization_campus, {foreignKey: 'organizationId', targetKey: 'id'});
  };
  return organization;
};
