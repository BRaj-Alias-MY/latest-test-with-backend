/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_type_map = sequelize.define('interview_type_map', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'organization_campus',
        key: 'id'
      }
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    interviews: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    days: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    startDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    expDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    maxInterviews: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    paymentMode: {
      type: DataTypes.ENUM('cc','dc','paypal','cheque'),
      allowNull: false
    },
    paymentStatus: {
      type: DataTypes.ENUM('open','inprogress','sucess','failed'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('pending','active','expired'),
      allowNull: false
    },
    paymentId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'payments',
        key: 'id'
      }
    },
    couponCode: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    cost: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    total: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_type_map'
  });
  interview_type_map.associate = function(models) {
    interview_type_map.hasMany(models.interview_type_map_child, {foreignKey: 'interviewTypeMapId', targetKey: 'id'});
    interview_type_map.belongsTo(models.payments, {foreignKey: 'paymentId', targetKey: 'id'});
  };
  return interview_type_map;
};
