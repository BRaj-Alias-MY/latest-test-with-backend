/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user_profile_edu', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    userProfileId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'user_profile',
        key: 'id'
      }
    },
    education: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    university: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    courseFrom: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    courseTo: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    specilization: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    grade: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'user_profile_edu'
  });
};
