/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const questions_temp = sequelize.define('questions_temp', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    question: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    answer: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    expLevelId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'exp_level',
        key: 'id'
      }
    },
    time:{
      type: DataTypes.INTEGER(11),
      allowNull: false,
    },
    difficulty: {
      type: DataTypes.ENUM('low','medium','heigh'),
      allowNull: false
    },
    mandatory: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    global: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    domainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'domain',
        key: 'id'
      }
    },
    subDomainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'sub_domains',
        key: 'id'
      }
    },
    keywords: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('open', 'accept', 'reject'),
      allowNull: false
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'questions_temp'
  });
  questions_temp.associate = function(models) {
    questions_temp.belongsTo(models.domain, {foreignKey: 'domainId', targetKey: 'id'});
    questions_temp.belongsTo(models.sub_domains, {foreignKey: 'subDomainId', targetKey: 'id'});
    questions_temp.belongsTo(models.exp_level, {foreignKey: 'expLevelId', targetKey: 'id'});
    questions_temp.belongsTo(models.users, {foreignKey: 'userId', targetKey: 'id'});
    questions_temp.hasMany(models.question_temp_remarks, {foreignKey: 'questionTempId', targetKey: 'id'});
  };
  return questions_temp;
};
