/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_experts_feedback = sequelize.define('interview_experts_feedback', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    interviewExpertId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_experts',
        key: 'id'
      }
    },
    interviewUserQuestionId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_user_questions',
        key: 'id'
      }
    },
    review: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rating: {
      type: DataTypes.ENUM('1','2','3','4','5'),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_experts_feedback'
  });
  interview_experts_feedback.associate = function(models) {
    interview_experts_feedback.belongsTo(models.interview_user_questions, {foreignKey: 'interviewUserQuestionId', targetKey: 'id'});
  };
  return interview_experts_feedback;
};
